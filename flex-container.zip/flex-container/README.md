# Flex Container

A Pen created on CodePen.

Original URL: [https://codepen.io/SANDRA-LIZBETH-MARTINEZCHAVEZ/pen/wBMreoY](https://codepen.io/SANDRA-LIZBETH-MARTINEZCHAVEZ/pen/wBMreoY).

